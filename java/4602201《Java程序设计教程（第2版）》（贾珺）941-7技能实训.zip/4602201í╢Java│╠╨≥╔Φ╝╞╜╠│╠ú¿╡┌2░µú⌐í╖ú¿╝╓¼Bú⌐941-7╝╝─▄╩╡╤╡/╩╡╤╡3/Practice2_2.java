/* Practice2_2.java */
public class Practice2_2 {
	public static void main(String[] args) {
		int k = 1;
		while (k <= 50)
		{
			System.out.print(k + " ");
			if (k % 5 == 0)
				System.out.print("\n"); 
			k++;
		}
	}
}
