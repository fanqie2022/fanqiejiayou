/* MoveTest.java */
package chapter5.practice1;
public class MoveTest {
	public static void main(String[] args) {
		Move s = new Student("ͬѧ");
		Move t = new Teacher("��ʦ");
		s.talk();
		t.talk();
		t.work();
		s.work();
	}
}
