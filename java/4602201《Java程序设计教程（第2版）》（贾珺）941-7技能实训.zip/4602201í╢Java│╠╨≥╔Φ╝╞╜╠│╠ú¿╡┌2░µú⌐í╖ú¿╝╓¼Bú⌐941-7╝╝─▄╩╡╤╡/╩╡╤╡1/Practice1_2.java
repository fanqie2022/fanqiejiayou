/* Practice1_2.java */
public class Practice1_2 {
	public static void main(String[] args) {
		int x = 2;
		int y = 3;
		int a = x + y;
		int b = x * y;
		int c = y / x;
		System.out.println("x + y = " + a);
		System.out.println("x * y = " + b);
		System.out.println("x / y = " + c);
	}
}
