
/* Practice1_1.java */
public class Practice1_1 {
	public static void main(String[] args) {
		System.out.println("   *   ");
		System.out.println("  ***  ");
		System.out.println(" ***** ");
	}
}

