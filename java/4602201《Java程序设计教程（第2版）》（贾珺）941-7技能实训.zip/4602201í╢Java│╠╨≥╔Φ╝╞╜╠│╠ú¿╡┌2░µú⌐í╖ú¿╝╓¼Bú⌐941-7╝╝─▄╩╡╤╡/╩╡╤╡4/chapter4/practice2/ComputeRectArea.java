/* ComputeRectArea.java */
package chapter4.practice2;
public class ComputeRectArea {
	public static void main(String args[]) {
		RectConstructor rect1 = new RectConstructor(10, 20);         
		double ar;
		ar = rect1.area();
		System.out.println("�����ε������" + ar);
	}
}
class RectConstructor {
	private double length;
	private double width;
	double area() {
		return length * width;         
	}
	RectConstructor(double width, double length) {
		this.length = length;
		this.width = width;         
	}
}


